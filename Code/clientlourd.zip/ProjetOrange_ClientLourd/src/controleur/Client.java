package controleur;

public class Client {
	private int idclient;
	private int codePostal;
	private String dateNaissance;
	
	public Client(int idclient, int codePostal, String dateNaissance)
	{
		this.idclient = idclient;
		this.codePostal = codePostal;
		this.dateNaissance = dateNaissance;
	}
	
	public Client(int codePostal, String dateNaissance)
	{
		this.idclient = 0;
		this.codePostal = codePostal;
		this.dateNaissance = dateNaissance;
	}

	public int getIdclient() {
		return idclient;
	}

	public void setIdclient(int idclient) {
		this.idclient = idclient;
	}

	public int getCodePostal() {
		return codePostal;
	}

	public void setCodePostal(int codePostal) {
		this.codePostal = codePostal;
	}

	public String getDateNaissance() {
		return dateNaissance;
	}

	public void setDateNaissance(String dateNaissance) {
		this.dateNaissance = dateNaissance;
	}

}
