package controleur;

import java.math.BigInteger;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;

import modele.ModeleUtilisateur;
import modele.ModeleIntervention;
import modele.ModeleProduit;

public class Controleur {
	
	public static String md5(String input) throws NoSuchAlgorithmException {
	    String result = input;
	    if(input != null) {
	        MessageDigest md = MessageDigest.getInstance("MD5"); //or "SHA-1"
	        md.update(input.getBytes());
	        BigInteger hash = new BigInteger(1, md.digest());
	        result = hash.toString(16);
	        while(result.length() < 32) { //40 for SHA-1
	            result = "0" + result;
	        }
	    }
	    return result;
	}
	
	// Fonctions Pour "Utilisateur"
	public static int insertUtilisateur(Utilisateur unUtilisateur)
	{
		// Controler les données
		if (unUtilisateur.getNom().isEmpty() || unUtilisateur.getPrenom().isEmpty() || unUtilisateur.getEmail().isEmpty()
				|| unUtilisateur.getMdp().isEmpty())
		{
			return -1;
		}
		
		ModeleUtilisateur.insertUtilisateur(unUtilisateur);
		return 0;
	}
	
	public static Utilisateur selectWhereAdministrateur(String email, String mdp)
	{
		// Controler les données
		if (email == "" || mdp == "")
			return null;
		
		// Il faudra ajouter le grain de sel avec une requete à la BDD
		// Il ne pas être codé en dur ici
		mdp = mdp + "1234567890";
		
		String hashmdp = "";
		try {
			hashmdp = md5(mdp);
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return ModeleUtilisateur.selectWhereAdministrateur(email, hashmdp);
	}
	
	public static Utilisateur selectWhereUtilisateur(String email, String mdp)
	{
		// Controler les données
		if (email == "" || mdp == "")
			return null;
		
		// Il faudra ajouter le grain de sel avec une requete à la BDD
		// Il ne pas être codé en dur ici
		mdp = mdp + "1234567890";
		
		String hashmdp = "";
		try {
			hashmdp = md5(mdp);
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return ModeleUtilisateur.selectWhereUtilisateur(email, hashmdp);
	}
	
	public static void modifierUtilisateur(Utilisateur unUtilisateur)
	{
		ModeleUtilisateur.modifierUtilisateur(unUtilisateur);
	}
	
	public static void modifierClient(Client unClient)
	{
		ModeleUtilisateur.modifierClient(unClient);
	}
	
	public static void modifierTechnicien(Technicien UnTechnicien)
	{
		ModeleUtilisateur.modifierTechnicien(UnTechnicien);
	}
	
	public static void deleteUtilisateur(int idUtilisateur)
	{
		ModeleUtilisateur.deleteUtilisateur(idUtilisateur);
	}
	
	public static ArrayList<Utilisateur> selectLikeUtilisateurs(String filtre)
	{
		return ModeleUtilisateur.selectLikeUtilisateurs(filtre);
	}
	
	public static String getUsername(int idutilisateur)
	{
		return ModeleUtilisateur.getUsername(idutilisateur);
	}
	
	public static void insertClient(Client unClient)
	{
		ModeleUtilisateur.insertClient(unClient);
	}
	
	public static void insertTechnicien(Technicien unTechnicien)
	{
		ModeleUtilisateur.insertTechnicien(unTechnicien);
	}
	
	public static ArrayList<Utilisateur> selectAllTechniciens()
	{	
		return ModeleUtilisateur.selectAllTechniciens();
	}
	
	public static ArrayList<Utilisateur> selectAllClients()
	{	
		return ModeleUtilisateur.selectAllClients();
	}
	
	public static Client getClientById(int idclient)
	{
		return ModeleUtilisateur.getClientById(idclient);
	}
	
	public static Technicien getTechnicienById(int idtechnicien)
	{
		return ModeleUtilisateur.getTechnicienById(idtechnicien);
	}
	
	
	// Fonctions pour "Produit"
	public static void insertProduit(Produit unProduit)
	{
		ModeleProduit.insertProduit(unProduit);
	}
	
	public static void updateProduit(Produit unProduit)
	{
		ModeleProduit.updateProduit(unProduit);
	}
	
	public static int selectProduitId(Produit unProduit)
	{
		return ModeleProduit.selectProduitId(unProduit);
	}
	
	public static Produit getProduitById(int idproduit)
	{
		return ModeleProduit.getProduitById(idproduit);
	}
	
	// Fonctions pour "Intervention"
	public static void insertIntervention(Intervention uneIntervention)
	{
		ModeleIntervention.insertIntervention(uneIntervention);
	}
	
	public static ArrayList<Intervention> selectLikeInterventions(String filtre)
	{
		return ModeleIntervention.selectLikeInterventions(filtre);
	}
	
	public static void updateIntervention(Intervention uneIntervention)
	{
		ModeleIntervention.updateIntervention(uneIntervention);
	}
	
	public static void deleteIntervention(int idIntervention)
	{
		ModeleIntervention.deleteIntervention(idIntervention);
	}
	
	public static int getInterventionProduitId(int idIntervention)
	{
		return ModeleIntervention.getInterventionProduitId(idIntervention);
	}
}