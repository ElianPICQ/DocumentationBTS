package controleur;

public class Intervention {
	private int idintervention;
	private String dateCreation, dateAcceptee, dateInter, description, statut;
	private float prix;
	private int duree, idproduit, idtechnicien, idclient;
	
	public Intervention(int idintervention, String dateCreation, String dateAcceptee, String dateInter,
			String description, String statut, float prix, int duree, int idproduit, int idtechnicien, int idclient)
	{
		super();
		this.idintervention = idintervention;
		this.dateCreation = dateCreation;
		this.dateAcceptee = dateAcceptee;
		this.dateInter = dateInter;
		this.description = description;
		this.statut = statut;
		this.prix = prix;
		this.duree = duree;
		this.idproduit = idproduit;
		this.idtechnicien = idtechnicien;
		this.idclient = idclient;
	}
	
	public Intervention(String dateCreation, String dateAcceptee, String dateInter, String description,
			String statut, float prix, int duree, int idproduit, int idtechnicien, int idclient)
	{
		super();
		this.idintervention = 0;
		this.dateCreation = dateCreation;
		this.dateAcceptee = dateAcceptee;
		this.dateInter = dateInter;
		this.description = description;
		this.statut = statut;
		this.prix = prix;
		this.duree = duree;
		this.idproduit = idproduit;
		this.idtechnicien = idtechnicien;
		this.idclient = idclient;
	}

	
	public int getIdintervention() {
		return idintervention;
	}

	public void setIdintervention(int idintervention) {
		this.idintervention = idintervention;
	}

	public String getDateCreation() {
		return dateCreation;
	}

	public void setDateCreation(String dateCreation) {
		this.dateCreation = dateCreation;
	}

	public String getDateAcceptee() {
		return dateAcceptee;
	}

	public void setDateAcceptee(String dateAcceptee) {
		this.dateAcceptee = dateAcceptee;
	}

	public String getDateInter() {
		return dateInter;
	}

	public void setDateInter(String dateInter) {
		this.dateInter = dateInter;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStatut() {
		return statut;
	}

	public void setStatut(String statut) {
		this.statut = statut;
	}

	public float getPrix() {
		return prix;
	}

	public void setPrix(float prix) {
		this.prix = prix;
	}

	public int getDuree() {
		return duree;
	}

	public void setDuree(int duree) {
		this.duree = duree;
	}

	public int getIdproduit() {
		return idproduit;
	}

	public void setIdproduit(int idproduit) {
		this.idproduit = idproduit;
	}

	public int getIdtechnicien() {
		return idtechnicien;
	}

	public void setIdtechnicien(int idtechnicien) {
		this.idtechnicien = idtechnicien;
	}

	public int getIdclient() {
		return idclient;
	}

	public void setIdclient(int idclient) {
		this.idclient = idclient;
	}
}
