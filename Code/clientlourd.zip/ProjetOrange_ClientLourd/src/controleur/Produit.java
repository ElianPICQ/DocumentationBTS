package controleur;

public class Produit {
	private int idproduit;
	private String nom, marque, urlImage, etat, categorie;
	int idClient;
	
	public Produit(int idproduit, String nom, String marque, String urlImage, String etat, String categorie, int idClient) {
		super();
		this.idproduit = idproduit;
		this.nom = nom;
		this.marque = marque;
		this.urlImage = urlImage;
		this.etat = etat;
		this.categorie = categorie;
		this.idClient = idClient;
	}
	
	public Produit(String nom, String marque, String urlImage, String etat, String categorie, int idClient) {
		super();
		this.idproduit = 0;
		this.nom = nom;
		this.marque = marque;
		this.urlImage = urlImage;
		this.etat = etat;
		this.categorie = categorie;
		this.idClient = idClient;
	}

	
	public int getIdproduit() {
		return idproduit;
	}

	public void setIdproduit(int idproduit) {
		this.idproduit = idproduit;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getMarque() {
		return marque;
	}

	public void setMarque(String marque) {
		this.marque = marque;
	}

	public String getUrlImage() {
		return urlImage;
	}

	public void setUrlImage(String urlImage) {
		this.urlImage = urlImage;
	}

	public String getEtat() {
		return etat;
	}

	public void setEtat(String etat) {
		this.etat = etat;
	}

	public String getCategorie() {
		return categorie;
	}

	public void setCategorie(String categorie) {
		this.categorie = categorie;
	}

	public int getIdClient() {
		return idClient;
	}

	public void setIdClient(int idClient) {
		this.idClient = idClient;
	}
}
