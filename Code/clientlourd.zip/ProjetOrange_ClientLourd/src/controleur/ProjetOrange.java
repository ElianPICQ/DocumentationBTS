package controleur;

import vue.VueConnexion;
import vue.VueGenerale;

public class ProjetOrange {

	private static VueConnexion uneVueConnexion;
	private static VueGenerale uneVueGenerale;
	
	public static void main(String args[])
	{
		uneVueConnexion = new VueConnexion();
//		uneVueGenerale = new VueGenerale();
	}
	
	public static void rendreVisibleConnexion (boolean action)
	{
		uneVueConnexion.setVisible(action);
	}
	
	public static void rendreVisibleGenerale (boolean action, Utilisateur unUtilisateur)
	{
		if (action == true)
		{
			uneVueGenerale = new VueGenerale(unUtilisateur);
			uneVueGenerale.setVisible(action);
		}
		else 
			uneVueGenerale.dispose();
	}
}
