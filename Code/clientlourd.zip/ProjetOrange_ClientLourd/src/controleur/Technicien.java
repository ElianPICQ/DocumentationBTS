package controleur;

public class Technicien {
	private int idtechnicien;
	private String competence, dateEmbauche;
	
	public Technicien(int idtechnicien, String competence, String dateEmbauche) {
		super();
		this.idtechnicien = idtechnicien;
		this.competence = competence;
		this.dateEmbauche = dateEmbauche;
	}
	
	public Technicien(String competence, String dateEmbauche) {
		super();
		this.idtechnicien = 0;
		this.competence = competence;
		this.dateEmbauche = dateEmbauche;
	}

	public int getIdtechnicien() {
		return idtechnicien;
	}

	public void setIdtechnicien(int idtechnicien) {
		this.idtechnicien = idtechnicien;
	}

	public String getCompetence() {
		return competence;
	}

	public void setCompetence(String competence) {
		this.competence = competence;
	}

	public String getDateEmbauche() {
		return dateEmbauche;
	}

	public void setDateEmbauche(String dateEmbauche) {
		this.dateEmbauche = dateEmbauche;
	}
}
