package modele;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import controleur.Intervention;

public class ModeleIntervention {
	private static Bdd uneBdd = new Bdd ("localhost:3307", "clientleger", "root", "");
	
	public static void insertIntervention(Intervention uneIntervention) {
		String requete = "INSERT INTO Intervention values (null, '" + uneIntervention.getDateCreation() + "', '"
				+ uneIntervention.getDateAcceptee() + "', '" + uneIntervention.getDateInter() + "', '"
				+ uneIntervention.getPrix() + "', '" + uneIntervention.getDuree() + "', '"
				+ uneIntervention.getDescription() + "', '" + uneIntervention.getStatut() + "', '"
				+ uneIntervention.getIdproduit() + "', '" + uneIntervention.getIdtechnicien() + "', '"
				+ uneIntervention.getIdclient() + "');";
		
		try {
			uneBdd.seConnecter();
			Statement unStat = uneBdd.getMaConnexion().createStatement();
			unStat.execute(requete);
			unStat.close();
			uneBdd.seDeconnecter();
		}
		catch (SQLException exp)
		{
			System.out.println("Erreur de requete : " + requete + "\n" + exp);
		}
	}
	
	
	public static ArrayList<Intervention> selectLikeInterventions(String filtre)
	{
		ArrayList<Intervention> lesInterventions = new ArrayList<Intervention>();
		
		String requete = "SELECT i.idintervention, i.date_creation_intervention, i.date_intervention_acceptee, "
				+ "i.date_intervention, i.description, i.statut, i.prix_intervention, i.duree, i.idproduit, i.idclient, i.idtechnicien "
				+ "FROM intervention i, produit p, lesClients c, lesTechniciens t "
				+ "WHERE i.idproduit = p.idproduit AND i.idclient = c.idutilisateur AND "
				+ "(p.nom_produit LIKE '%" + filtre
				+ "%' OR p.etat LIKE '%" + filtre
				+ "%' OR p.categorie LIKE '%" + filtre
				+ "%' OR i.date_creation_intervention LIKE '%" + filtre
				+ "%' OR i.date_intervention_acceptee LIKE '%" + filtre
				+ "%' OR i.date_intervention LIKE '%" + filtre
				+ "%' OR i.prix_intervention LIKE '%" + filtre
				+ "%' OR i.duree LIKE '%" + filtre
				+ "%' OR i.description LIKE '%" + filtre
				+ "%' OR i.statut LIKE '%" + filtre
				+ "%' OR c.nom LIKE '%" + filtre
				+ "%' OR t.nom LIKE '%" + filtre
				+ "%') GROUP BY i.idintervention;";
		
		try {
			uneBdd.seConnecter();
			
			// Création d'un curseur pour executer le nouveau
			Statement unStat = uneBdd.getMaConnexion().createStatement();
			// Execution de la requete et récupération d'un résultat
			ResultSet desRes = unStat.executeQuery(requete);
			// Si il y a un résultat, on récupère les champs
			while (desRes.next())
			{
				Intervention uneIntervention = new Intervention(
						desRes.getInt("idintervention"),
						desRes.getString("date_creation_intervention"),
						desRes.getString("date_intervention_acceptee"),
						desRes.getString("date_intervention"),
						desRes.getString("description"),
						desRes.getString("statut"),
						desRes.getFloat("prix_intervention"),
						desRes.getInt("duree"),
						desRes.getInt("idproduit"),
						desRes.getInt("idtechnicien"),
						desRes.getInt("idclient")
						);
				lesInterventions.add(uneIntervention);
			}
			unStat.close();
			uneBdd.seDeconnecter();	
		}
		catch (SQLException exp) {
			System.out.println("Erreur de requete : " + requete + "\n" + exp);
		}
		return lesInterventions;
	}
	
	
	public static void updateIntervention(Intervention uneIntervention)
	{
		String requete = "UPDATE Intervention SET date_creation_intervention = '" + uneIntervention.getDateCreation()
				+ "', date_intervention_acceptee = '" + uneIntervention.getDateAcceptee()
				+ "', date_intervention = '" + uneIntervention.getDateInter()
				+ "', prix_intervention = '" + uneIntervention.getPrix()
				+ "', duree = '" + uneIntervention.getDuree()
				+ "', description = '" + uneIntervention.getDescription()
				+ "', statut = '" + uneIntervention.getStatut()
				+ "', idproduit = '" + uneIntervention.getIdproduit()
				+ "', idtechnicien = '" + uneIntervention.getIdtechnicien()
				+ "', idclient = '" + uneIntervention.getIdclient()
				+ "'WHERE idintervention = " + uneIntervention.getIdintervention() + ";";
		try {
			uneBdd.seConnecter();
			Statement unStat = uneBdd.getMaConnexion().createStatement();
			unStat.execute(requete);
			unStat.close();
			uneBdd.seDeconnecter();
		}
		catch (SQLException exp)
		{
			System.out.println("Erreur de requete : " + requete + "\n" + exp);
		}
	}
	
	public static void deleteIntervention(int idIntervention)
	{
		String requete = "DELETE FROM Intervention WHERE idintervention = '" + idIntervention + "';";
		
		try {
			uneBdd.seConnecter();
			Statement unStat = uneBdd.getMaConnexion().createStatement();
			unStat.execute(requete);
			unStat.close();
			uneBdd.seDeconnecter();
		}
		catch (SQLException exp)
		{
			System.out.println("Erreur de requete : " + requete + "\n" + exp);
		}
	}
	
	
	public static int getInterventionProduitId(int idIntervention)
	{
		int idProduit = 0;
		String requete = "SELECT idproduit from Intervention WHERE idintervention = '" + idIntervention + "';";
		
		try {
			uneBdd.seConnecter();
			
			// Création d'un curseur pour executer le nouveau
			Statement unStat = uneBdd.getMaConnexion().createStatement();
			// Execution de la requete et récupération d'un résultat
			ResultSet desRes = unStat.executeQuery(requete);
			// Si il y a un résultat, on récupère les champs
			while (desRes.next())
			{
				idProduit = desRes.getInt("idproduit");
			}
			unStat.close();
			uneBdd.seDeconnecter();
		}
		catch (SQLException exp) {
			System.out.println("Erreur de requete : " + requete + "\n" + exp);
		}
		return idProduit;
	}
}
