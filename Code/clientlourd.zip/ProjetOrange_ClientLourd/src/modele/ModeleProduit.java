package modele;

import java.sql.ResultSet;

import java.sql.SQLException;
import java.sql.Statement;

import controleur.Produit;


public class ModeleProduit {
	private static Bdd uneBdd = new Bdd ("localhost:3307", "clientleger", "root", "");
	
	public static void insertProduit(Produit unProduit) {		
		String requete = "INSERT INTO Produit values (null, '" + unProduit.getNom() + "', '"
					+ unProduit.getMarque() + "', '" + unProduit.getUrlImage() + "', '" + unProduit.getEtat() + "', '"
				+ unProduit.getCategorie() +  "', '" + unProduit.getIdClient() + "');";
		
		try {
			uneBdd.seConnecter();
			Statement unStat = uneBdd.getMaConnexion().createStatement();
			unStat.execute(requete);
			
			unStat.close();
			uneBdd.seDeconnecter();
		}
		catch (SQLException exp)
		{
			System.out.println("Erreur de requete : " + requete + "\n" + exp);
		}		
	}
	
	public static void updateProduit(Produit unProduit)
	{
		String requete = "UPDATE Produit SET nom_produit = '" + unProduit.getNom() + "', marque = '" + unProduit.getMarque()
				+ "', url_image = '" + unProduit.getUrlImage() + "', etat = '" + unProduit.getEtat()
				+ "', categorie = '" + unProduit.getCategorie() + "', idclient = '" + unProduit.getIdClient()
				+ "'WHERE idproduit = '" + unProduit.getIdproduit() + "';";

		try {
			uneBdd.seConnecter();
			Statement unStat = uneBdd.getMaConnexion().createStatement();
			unStat.execute(requete);
			unStat.close();
			uneBdd.seDeconnecter();
		}
		catch (SQLException exp)
		{
			System.out.println("Erreur de requete : " + requete + "\n" + exp);
		}
	}
	
	public static int selectProduitId(Produit unProduit)
	{
		String requete = "SELECT * FROM Produit WHERE nom_produit = '" + unProduit.getNom()
		+ "' AND marque = '" + unProduit.getMarque() + "' AND url_image = '" + unProduit.getUrlImage()
		+ "' AND etat = '" + unProduit.getEtat() + "' AND categorie = '" + unProduit.getCategorie()
		+ "' AND idclient = '" + unProduit.getIdClient() + "';";
		
		int idproduit = 0;
		
		try {
			uneBdd.seConnecter();
			Statement unStat = uneBdd.getMaConnexion().createStatement();
			
			ResultSet desRes = unStat.executeQuery(requete);
			
			
			while (desRes.next())
			{
				idproduit = desRes.getInt("idproduit");
			}
			
			unStat.close();
			uneBdd.seDeconnecter();
		}
		catch (SQLException exp)
		{
			System.out.println("Erreur de requete : " + requete + "\n" + exp);
		}
		
		return idproduit;
	}
		
	
	public static Produit getProduitById(int idproduit)
	{
		Produit unProduit = null;
		
		String requete = "SELECT * FROM Produit WHERE idproduit = '" + idproduit + "';";
		try {
			uneBdd.seConnecter();
			
			// Création d'un curseur pour executer le nouveau
			Statement unStat = uneBdd.getMaConnexion().createStatement();
			// Execution de la requete et récupération d'un résultat
			ResultSet unRes = unStat.executeQuery(requete);
			// Si il y a un résultat, on récupère les champs		
			if (unRes.next())
			{
				unProduit = new Produit(
						unRes.getInt("idproduit"),
						unRes.getString("nom_produit"),
						unRes.getString("marque"),
						unRes.getString("url_image"),
						unRes.getString("etat"),
						unRes.getString("categorie"),
						unRes.getInt("idClient")
						);
			}
			unStat.close();
			uneBdd.seDeconnecter();	
		}
		catch (SQLException exp) {
			System.out.println("Erreur de requete : " + requete + "\n" + exp);
		}
		return unProduit;
	}


}
