package modele;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import controleur.Utilisateur;
import controleur.Client;
import controleur.Technicien;

public class ModeleUtilisateur {
	private static Bdd uneBdd = new Bdd ("localhost:3307", "clientleger", "root", "");
	
	public static void insertUtilisateur(Utilisateur unUtilisateur)
	{
		String requete = "INSERT into utilisateur values (null, '" + unUtilisateur.getNom() + "', '"
				+ unUtilisateur.getPrenom() + "', '" + unUtilisateur.getEmail() + "', '"
				+ unUtilisateur.getTel() + "', '" + unUtilisateur.getMdp() + "', '"
				+ unUtilisateur.getRole() + "');";
		
		try {
			uneBdd.seConnecter();
			
			Statement unStat = uneBdd.getMaConnexion().createStatement();
			unStat.execute(requete);
			unStat.close();
			uneBdd.seDeconnecter();
		}
		catch (SQLException exp)
		{
			System.out.println("Erreur de requete : " + requete + "\n" + exp);
		}
	}

	
	public static Utilisateur selectWhereAdministrateur(String email, String hashmdp)
	{
		Utilisateur unUtilisateur = null;
		
		String requete = "SELECT * FROM Utilisateur WHERE email = '" + email + "' and mot_de_passe = '" + hashmdp + "' AND role = 'administrateur';";
		try {
			uneBdd.seConnecter();
			
			// Création d'un curseur pour executer le nouveau
			Statement unStat = uneBdd.getMaConnexion().createStatement();
			// Execution de la requete et récupération d'un résultat
			ResultSet unRes = unStat.executeQuery(requete);
			// Si il y a un résultat, on récupère les champs		
			if (unRes.next())
			{
				unUtilisateur = new Utilisateur(
						unRes.getInt("idutilisateur"),
						unRes.getString("nom"),
						unRes.getString("prenom"),
						unRes.getString("email"),
						unRes.getString("tel"),
						unRes.getString("mot_de_passe"),
						unRes.getString("role")
						);
			}
			unStat.close();
			uneBdd.seDeconnecter();	
		}
		catch (SQLException exp) {
			System.out.println("Erreur de requete : " + requete);
		}
		
		return unUtilisateur;
	}
	
	
	public static Utilisateur selectWhereUtilisateur(String email, String hashmdp)
	{
		Utilisateur unUtilisateur = null;
		
		String requete = "SELECT * FROM Utilisateur WHERE email = '" + email + "' and mot_de_passe = '" + hashmdp + "';";
		try {
			uneBdd.seConnecter();
			
			// Création d'un curseur
			Statement unStat = uneBdd.getMaConnexion().createStatement();
			// Execution de la requete et récupération d'un résultat
			ResultSet unRes = unStat.executeQuery(requete);
			// Si il y a un résultat, on récupère les champs		
			if (unRes.next())
			{
				unUtilisateur = new Utilisateur(
						unRes.getInt("idutilisateur"),
						unRes.getString("nom"),
						unRes.getString("prenom"),
						unRes.getString("email"),
						unRes.getString("tel"),
						unRes.getString("mot_de_passe"),
						unRes.getString("role")
						);
			}
			unStat.close();
			uneBdd.seDeconnecter();	
		}
		catch (SQLException exp) {
			System.out.println("Erreur de requete : " + requete + "\n" + exp);
		}
		
		return unUtilisateur;
	}
	
	
	public static void modifierUtilisateur(Utilisateur unUtilisateur)
	{
		String requete = "UPDATE Utilisateur SET nom = '" + unUtilisateur.getNom() + "', prenom = '" + unUtilisateur.getPrenom()
						+ "', email = '" + unUtilisateur.getEmail() + "', tel = '" + unUtilisateur.getTel()
						+ "', mot_de_passe = '" + unUtilisateur.getMdp()
						+ "' WHERE idutilisateur = '" + unUtilisateur.getIdutilisateur() + "';";
		
		try {
			uneBdd.seConnecter();
			Statement unStat = uneBdd.getMaConnexion().createStatement();
			unStat.execute(requete);
			unStat.close();
			uneBdd.seDeconnecter();
		}
		catch (SQLException exp)
		{
			System.out.println("Erreur de requete : " + requete + "\n" + exp);
		}	
	}
	
	
	public static void modifierClient(Client unClient)
	{
		String requete = "UPDATE Client SET code_postal = '" + unClient.getCodePostal() + "', date_naissance = '" + unClient.getDateNaissance()
						+ "' WHERE idclient = '" + unClient.getIdclient() + "';";
		
		try {
			uneBdd.seConnecter();
			Statement unStat = uneBdd.getMaConnexion().createStatement();
			unStat.execute(requete);
			unStat.close();
			uneBdd.seDeconnecter();
		}
		catch (SQLException exp)
		{
			System.out.println("Erreur de requete : " + requete + "\n" + exp);
		}	
	}
	
	
	public static void modifierTechnicien(Technicien unTechnicien)
	{
		String requete = "UPDATE Technicien SET competence = '" + unTechnicien.getCompetence() + "', date_embauche = '" + unTechnicien.getDateEmbauche()
						+ "' WHERE idclient = '" + unTechnicien.getIdtechnicien() + "';";
		
		try {
			uneBdd.seConnecter();
			Statement unStat = uneBdd.getMaConnexion().createStatement();
			unStat.execute(requete);
			unStat.close();
			uneBdd.seDeconnecter();
		}
		catch (SQLException exp)
		{
			System.out.println("Erreur de requete : " + requete + "\n" + exp);
		}	
	}
	
	
	public static void deleteUtilisateur(int idUtilisateur)
	{
		String requete = "DELETE FROM Utilisateur WHERE idUtilisateur = '" + idUtilisateur +"';";
		
		try {
			uneBdd.seConnecter();
			Statement unStat = uneBdd.getMaConnexion().createStatement();
			unStat.execute(requete);
			unStat.close();
			uneBdd.seDeconnecter();
		}
		catch (SQLException exp)
		{
			System.out.println("Erreur de requete : " + requete + "\n" + exp);
		}
	}
	
	
	public static ArrayList<Utilisateur> selectLikeUtilisateurs(String filtre)
	{
		ArrayList<Utilisateur> lesUtilisateurs = new ArrayList<Utilisateur>();
				
		String requete = "SELECT DISTINCT u.idutilisateur, u.nom, u.prenom, u.email, u.tel, u.mot_de_passe, u.role"
				+ " FROM utilisateur u, client c, technicien t"
				+ " WHERE u.nom LIKE '%" + filtre
				+ "%' OR u.prenom LIKE '%" + filtre
				+ "%' OR u.email LIKE '%" + filtre
				+ "%' OR u.tel LIKE '%" + filtre
				+ "%' OR u.role LIKE '%" + filtre
				+ "%' OR c.code_postal LIKE '%" + filtre
				+ "%' OR c.date_naissance LIKE '%" + filtre
				+ "%' OR t.competence LIKE '%" + filtre
				+ "%' OR t.date_embauche LIKE '%" + filtre + "%';";
				
		
		try {
			uneBdd.seConnecter();
			
			// Création d'un curseur pour executer le nouveau
			Statement unStat = uneBdd.getMaConnexion().createStatement();
			// Execution de la requete et récupération d'un résultat
			ResultSet desRes = unStat.executeQuery(requete);
			// Si il y a un résultat, on récupère les champs
			while (desRes.next())
			{
				Utilisateur unUtilisateur = new Utilisateur(
						desRes.getInt("idutilisateur"),
						desRes.getString("nom"),
						desRes.getString("prenom"),
						desRes.getString("email"),
						desRes.getString("tel"),
						desRes.getString("mot_de_passe"),
						desRes.getString("role")
						);
				lesUtilisateurs.add(unUtilisateur);
			}
			unStat.close();
			uneBdd.seDeconnecter();	
		}
		catch (SQLException exp) {
			System.out.println("Erreur de requete : " + requete + "\n" + exp);
		}
		return lesUtilisateurs;
	}
	
	
	public static String getUsername(int idutilisateur)
	{
		String nom = "";
		String requete = "SELECT nom FROM utilisateur WHERE idutilisateur = '" + idutilisateur + "';";
		
		try {
			uneBdd.seConnecter();
			
			Statement unStat = uneBdd.getMaConnexion().createStatement();
			ResultSet unRes = unStat.executeQuery(requete);
			
			if (unRes.next())
			{	
				nom = unRes.getString("nom");
			}
		}
		catch (SQLException exp) {
			System.out.println("Erreur de requete : " + requete + "\n" + exp);
		}
		
		return nom;
	}
	
	
	public static void insertClient(Client unClient)
	{
		String requete = "INSERT into Client values ('" + unClient.getIdclient() + "', '" + unClient.getCodePostal() + "', '"
				+ unClient.getDateNaissance() + "');";
		
		try {
			uneBdd.seConnecter();
			
			Statement unStat = uneBdd.getMaConnexion().createStatement();
			unStat.execute(requete);
			unStat.close();
			uneBdd.seDeconnecter();
		}
		catch (SQLException exp)
		{
			System.out.println("Erreur de requete : " + requete + "\n" + exp);
		}
	}
	
	
	public static void insertTechnicien(Technicien unTechnicien)
	{
		String requete = "INSERT into Technicien values ('" + unTechnicien.getIdtechnicien() + "', '" + unTechnicien.getCompetence() + "', '"
				+ unTechnicien.getDateEmbauche() + "');";
		
		try {
			uneBdd.seConnecter();
			
			Statement unStat = uneBdd.getMaConnexion().createStatement();
			unStat.execute(requete);
			unStat.close();
			uneBdd.seDeconnecter();
		}
		catch (SQLException exp)
		{
			System.out.println("Erreur de requete : " + requete + "\n" + exp);
		}
	}
	
	
	public static Client getClientById(int idclient)
	{
		Client unClient = null;
		
		String requete = "SELECT * FROM Client WHERE idclient = '" + idclient + "';";
		
		try {
			uneBdd.seConnecter();
			
			// Création d'un curseur pour executer le nouveau
			Statement unStat = uneBdd.getMaConnexion().createStatement();
			// Execution de la requete et récupération d'un résultat
			ResultSet unRes = unStat.executeQuery(requete);
			// Si il y a un résultat, on récupère les champs
			if (unRes.next())
			{
				unClient = new Client(
						unRes.getInt("idclient"),
						unRes.getInt("code_postal"),
						unRes.getString("date_naissance")
						);
			}
			unStat.close();
			uneBdd.seDeconnecter();	
		}
		catch (SQLException exp) {
			System.out.println("Erreur de requete : " + requete + "\n" + exp);
		}
		return unClient;
	}
	
	public static Technicien getTechnicienById(int idtechnicien)
	{
		Technicien unTechnicien = null;
		
		String requete = "SELECT * FROM Technicien WHERE idtechnicien = '" + idtechnicien + "';";
		
		try {
			uneBdd.seConnecter();
			
			// Création d'un curseur pour executer le nouveau
			Statement unStat = uneBdd.getMaConnexion().createStatement();
			// Execution de la requete et récupération d'un résultat
			ResultSet unRes = unStat.executeQuery(requete);
			// Si il y a un résultat, on récupère les champs
			if (unRes.next())
			{
				unTechnicien = new Technicien(
						unRes.getInt("idtechnicien"),
						unRes.getString("competence"),
						unRes.getString("date_embauche")
						);
			}
			unStat.close();
			uneBdd.seDeconnecter();	
		}
		catch (SQLException exp) {
			System.out.println("Erreur de requete : " + requete + "\n" + exp);
		}
		return unTechnicien;
	}


	public static ArrayList<Utilisateur> selectAllTechniciens()
	{
		ArrayList<Utilisateur> lesTechniciens = new ArrayList<Utilisateur>();
		
		String requete = "SELECT * FROM Utilisateur WHERE role = 'technicien';";
		try {
			uneBdd.seConnecter();
			
			// Création d'un curseur pour executer le nouveau
			Statement unStat = uneBdd.getMaConnexion().createStatement();
			// Execution de la requete et récupération d'un résultat
			ResultSet desRes = unStat.executeQuery(requete);
			// Si il y a un résultat, on récupère les champs
			while (desRes.next())
			{
				Utilisateur unTechnicien = new Utilisateur(
						desRes.getInt("idutilisateur"),
						desRes.getString("nom"),
						desRes.getString("prenom"),
						desRes.getString("email"),
						desRes.getString("tel"),
						desRes.getString("mot_de_passe"),
						desRes.getString("role")
						);
				lesTechniciens.add(unTechnicien);
			}
			unStat.close();
			uneBdd.seDeconnecter();	
		}
		catch (SQLException exp) {
			System.out.println("Erreur de requete : " + requete + "\n" + exp);
		}
		
		return lesTechniciens;
	}


	public static ArrayList<Utilisateur> selectAllClients()
	{
		ArrayList<Utilisateur> lesClients = new ArrayList<Utilisateur>();
		
		String requete = "SELECT * FROM Utilisateur WHERE role = 'client';";
		try {
			uneBdd.seConnecter();
			
			// Création d'un curseur pour executer le nouveau
			Statement unStat = uneBdd.getMaConnexion().createStatement();
			// Execution de la requete et récupération d'un résultat
			ResultSet desRes = unStat.executeQuery(requete);
			// Si il y a un résultat, on récupère les champs
			while (desRes.next())
			{
				Utilisateur unClient = new Utilisateur(
						desRes.getInt("idutilisateur"),
						desRes.getString("nom"),
						desRes.getString("prenom"),
						desRes.getString("email"),
						desRes.getString("tel"),
						desRes.getString("mot_de_passe"),
						desRes.getString("role")
						);
				lesClients.add(unClient);
			}
			unStat.close();
			uneBdd.seDeconnecter();	
		}
		catch (SQLException exp) {
			System.out.println("Erreur de requete : " + requete);
		}
		
		return lesClients;
	}
}

















