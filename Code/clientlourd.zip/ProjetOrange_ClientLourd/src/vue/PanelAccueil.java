package vue;import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;

import controleur.Utilisateur;

public class PanelAccueil extends PanelPrincipal {

	private JPanel panelInfos = new JPanel();
	
	public PanelAccueil()
	{
		super(new Color(215, 215, 215));
		
		this.panelInfos.setBounds(50, 50, 300, 250);
		this.panelInfos.setBackground(new Color(150, 150, 150));
		this.panelInfos.setLayout(new GridLayout(5, 1));
		
		this.add(this.panelInfos);
		
		this.panelInfos.setVisible(true);
	}
	
	public PanelAccueil(Utilisateur unUtilisateur)
	{
		super(new Color(215, 215, 215));
		
		this.panelInfos.setBounds(50, 50, 300, 250);
		this.panelInfos.setBackground(new Color(215, 215, 215));
		this.panelInfos.setLayout(new GridLayout(5, 1));
		
		this.panelInfos.add(new JLabel("Boujour " + unUtilisateur.getNom() + " " + unUtilisateur.getPrenom()));
		this.panelInfos.add(new JLabel("Votre Email : " + unUtilisateur.getEmail()));
		this.panelInfos.add(new JLabel("Votre N° de Tel : " + unUtilisateur.getTel()));
		
		this.add(this.panelInfos);
		
		this.panelInfos.setVisible(true);
	}
	
	public void remplirDonnees(Utilisateur unUtilisateur)
	{

		panelInfos.add(new JLabel("Boujour " + unUtilisateur.getNom() + " " + unUtilisateur.getPrenom()));
		panelInfos.add(new JLabel("Votre Email : "));
		panelInfos.add(new JLabel(unUtilisateur.getEmail()));
		panelInfos.add(new JLabel("Votre N° de Tel : "));
		panelInfos.add(new JLabel(unUtilisateur.getTel()));
	}
}
