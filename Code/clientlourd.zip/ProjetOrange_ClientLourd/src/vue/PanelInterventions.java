package vue;

import java.text.Normalizer;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.JTextArea;
import javax.swing.JTextField;

import controleur.Controleur;
import controleur.Intervention;
import controleur.Produit;
import controleur.Tableau;
import controleur.Utilisateur;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import javax.swing.table.DefaultTableCellRenderer;




public class PanelInterventions extends PanelPrincipal implements ActionListener
{
	private JTextField txtNomProduit = new JTextField();
	private JTextField txtMarque = new JTextField();
	private JComboBox<String> txtEtat = new JComboBox<String>();
	private JComboBox<String> txtCategorie = new JComboBox<String>();
	private JTextField txtDateCreationIntervention = new JTextField();
	private JTextField txtDateInterventionAcceptee = new JTextField();
	private JTextField dateInter = new JTextField();
	private JTextField txtPrix = new JTextField();
	private JTextField txtDuree = new JTextField();
	private JTextArea txtDescription = new JTextArea(8, 20);
	private JScrollPane txtDescriptionScroll = new JScrollPane(txtDescription);
	private JComboBox<String> txtStatut = new JComboBox<String>();
	private JComboBox<String> txtIdTechnicien = new JComboBox<String>();
	private JComboBox<String> txtIdClient = new JComboBox<String>();
	
	private JButton btAnnuler = new JButton("Annuler");
	private JButton btEnregistrer = new JButton("Enregistrer");

	private JPanel panelForm = new JPanel();
	private JPanel panelFormComplet = new JPanel();
	private JPanel panelFormBtns = new JPanel();

	// Table affichage
	private JTable tableProduits;
	private JScrollPane unScroll;
	private Tableau unTableau;

	// Champ & bouton filtre
	private JPanel panelRech = new JPanel();
	private JTextField txtFiltre = new JTextField();
	private JButton btFiltre = new JButton("Filtrer");
	private JButton btEnleverFiltre = new JButton("X");
	
	
	public PanelInterventions()
	{
		super(Color.gray);
		
		this.panelForm.setBounds(10, 50, 270, 300);
		this.panelForm.setBackground(new Color(181, 135, 79));
		this.panelForm.setLayout(new GridLayout(8, 2));
		
		this.panelForm.add(new JLabel("Produit : "));
		this.panelForm.add(this.txtNomProduit);
		this.panelForm.add(new JLabel("Marque : "));
		this.panelForm.add(this.txtMarque);
		this.panelForm.add(new JLabel("Etat : "));
		this.panelForm.add(this.txtEtat);
		this.panelForm.add(new JLabel("Catégorie : "));
		this.panelForm.add(this.txtCategorie);
		this.panelForm.add(new JLabel("Date de creation de l'intervention : "));
		this.panelForm.add(this.txtDateCreationIntervention);
		this.panelForm.add(new JLabel("Description : "));
		this.panelForm.add(this.txtDescriptionScroll);
		this.panelForm.add(new JLabel("Le Client : "));
		this.panelForm.add(this.txtIdClient);
		this.panelForm.add(new JLabel("Status : "));
		this.panelForm.add(this.txtStatut);
		
		this.panelFormComplet.setBounds(10, 350, 270, 150);
		this.panelFormComplet.setBackground(new Color(255, 0, 0));
		this.panelFormComplet.setLayout(new GridLayout(5, 2));

		this.panelFormComplet.add(new JLabel("Le Technicien : "));
		this.panelFormComplet.add(this.txtIdTechnicien);
		this.panelFormComplet.add(new JLabel("Prix : "));
		this.panelFormComplet.add(this.txtPrix);
		this.panelFormComplet.add(new JLabel("Durée : "));
		this.panelFormComplet.add(this.txtDuree);
		this.panelFormComplet.add(new JLabel("Date de prise en charge de l'intervention : "));
		this.panelFormComplet.add(this.txtDateInterventionAcceptee);
		this.panelFormComplet.add(new JLabel("Date de l'intervention : "));
		this.panelFormComplet.add(this.dateInter);
		
		this.panelFormBtns.setBounds(10, 500, 270, 30);
		this.panelFormBtns.setBackground(new Color(255, 0, 0));
		this.panelFormBtns.setLayout(new GridLayout(1, 2));
		
		this.panelFormBtns.add(this.btAnnuler);
		this.panelFormBtns.add(this.btEnregistrer);

		this.add(this.panelForm);
		this.add(this.panelFormComplet);
		this.add(this.panelFormBtns);
		
		this.panelForm.setVisible(true);
		this.panelFormComplet.setVisible(false);
		
		// Ecouter les changements sur le ComboBox Statut
		this.txtStatut.addItemListener(new ItemListener( ) {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == 1) {
					panelFormComplet.setVisible(false);
					
					Object item = e.getItem();
					
					switch (item.toString()) {
						case "En Attente": panelFormComplet.setVisible(false); break;
						case "Acceptée":
						case "En cours":
						case "Terminée":
						case "Refusée": panelFormComplet.setVisible(true); break;
							
						default: break;
					}
				}
			}
		});
		
		this.remplirCBX();
		
		
		// Affichage des Interventions
		// Construction de la JTable
		String entetes [] = {"ID Intervention", "Produit", "Marque", "Etat", "Catégorie", "Date de Création", "Date de prise en charge",
				"Date de l'intervention", "Prix", "Durée", "Description", "Statut", "Technicien", "Client"};
		this.unTableau = new Tableau (entetes, this.obtenirDonnees(""));
		this.tableProduits = new JTable(this.unTableau);
		
		//this.unScroll = new JScrollPane(this.tableProduits);
		this.unScroll = new JScrollPane(this.tableProduits);
		this.unScroll.setBounds(290, 50, 800, 480);
		this.add(this.unScroll);
		
		this.tableProduits.setAutoResizeMode( JTable.AUTO_RESIZE_OFF );
		
		
		// Interdiction de déplacement des colonnes
		this.tableProduits.getTableHeader().setReorderingAllowed(false);

		// Placemement du panel filtre
		this.panelRech.setBounds(450, 10, 300, 20);
		this.panelRech.setBackground(new Color(152, 45, 20));
		this.panelRech.setLayout(new GridLayout(1, 4));
		this.panelRech.add(this.btEnleverFiltre);
		this.panelRech.add(new JLabel("Filtrer par : "));
		this.panelRech.add(this.txtFiltre);
		this.panelRech.add(this.btFiltre);
		this.panelRech.setVisible(true);
		this.add(this.panelRech);
		
		// Rendre les boutons cliquables
		this.btAnnuler.addActionListener(this);
		this.btEnregistrer.addActionListener(this);
		this.btFiltre.addActionListener(this);
		this.btEnleverFiltre.addActionListener(this);
		
		// On centre les infos dans le tableau
		DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);

        for (int i = 0 ; i < entetes.length ; i++)
        {
	        tableProduits.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
        
        // On donne manuellement la largeur des colonnes
        tableProduits.getColumnModel().getColumn(0).setMinWidth(100);
        tableProduits.getColumnModel().getColumn(1).setMinWidth(120);
        tableProduits.getColumnModel().getColumn(2).setMinWidth(100);
        tableProduits.getColumnModel().getColumn(3).setMinWidth(100);
        tableProduits.getColumnModel().getColumn(4).setMinWidth(100);
        tableProduits.getColumnModel().getColumn(5).setMinWidth(90);
        tableProduits.getColumnModel().getColumn(6).setMinWidth(90);
        tableProduits.getColumnModel().getColumn(7).setMinWidth(90);
        tableProduits.getColumnModel().getColumn(8).setMinWidth(60);
        tableProduits.getColumnModel().getColumn(9).setMinWidth(60);
        tableProduits.getColumnModel().getColumn(10).setMinWidth(200);
        tableProduits.getColumnModel().getColumn(11).setMinWidth(80);
        tableProduits.getColumnModel().getColumn(12).setMinWidth(90);
        tableProduits.getColumnModel().getColumn(13).setMinWidth(90);
		
		// Ajout d'un 'mouse listener' pour la suppression et la modification
		this.tableProduits.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseClicked(MouseEvent e)
			{
				int numLigne = 0;
				int idIntervention = 0;
				
				numLigne = tableProduits.getSelectedRow();
				idIntervention = Integer.parseInt(tableProduits.getValueAt(numLigne,  0).toString());
				
				if (e.getClickCount() >= 2)
				{
					int reponse = JOptionPane.showConfirmDialog(null, "Voulez vous vraiment supprimer cette intervention?", "Suppression Intervention", JOptionPane.YES_NO_OPTION);
					
					if (reponse == 0)
					{
						// Suppression dans la BDD
						Controleur.deleteIntervention(idIntervention);
						// Suppression dans la table affichée
						unTableau.supprimerLigner(numLigne);
					}
				}
				else
				{
					String nom = tableProduits.getValueAt(numLigne, 1).toString();
					String marque = tableProduits.getValueAt(numLigne, 2).toString();
//					String etat = tableProduits.getValueAt(numLigne, 3).toString();
//					String categorie = tableProduits.getValueAt(numLigne, 4).toString();
					String dateCreation = tableProduits.getValueAt(numLigne, 5).toString();
					String dateAcceptee = tableProduits.getValueAt(numLigne, 6).toString();
					String dateInterv = tableProduits.getValueAt(numLigne, 7).toString();
					String prix = tableProduits.getValueAt(numLigne, 8).toString();
					String duree = tableProduits.getValueAt(numLigne, 9).toString();
					String description = tableProduits.getValueAt(numLigne, 10).toString();
//					String statut = tableProduits.getValueAt(numLigne, 11).toString();
//					String technicien = tableProduits.getValueAt(numLigne, 12).toString();
//					String client = tableProduits.getValueAt(numLigne, 13).toString();
					
					// Remplissage du formulaire
					txtNomProduit.setText(nom);
					txtMarque.setText(marque);
//					txtEtat.setText(etat);
//					txtCategorie.setText(categorie);
					txtDateCreationIntervention.setText(dateCreation);
					txtDateInterventionAcceptee.setText(dateAcceptee);
					dateInter.setText(dateInterv);
					txtPrix.setText(prix);
					txtDuree.setText(duree);
					txtDescription.setText(description);
//					txtStatut.setText(statut);
//					txtIdTechnicien.setText(technicien);
//					txtIdClient.setText(client);
						
					btEnregistrer.setText("Modifier");
				}
			}
		});
	}
	
	// Pour remplir les JComboBox
	public void remplirCBX()
	{
		ArrayList<Utilisateur> lesTechniciens = Controleur.selectAllTechniciens();
		for (Utilisateur unTechnicien : lesTechniciens)
		{
			this.txtIdTechnicien.addItem(unTechnicien.getIdutilisateur() + "-" + unTechnicien.getNom());
		}
		
		ArrayList<Utilisateur> lesClients = Controleur.selectAllClients();
		for (Utilisateur unClient : lesClients)
		{
			this.txtIdClient.addItem(unClient.getIdutilisateur() + "-" + unClient.getNom());
		}

		this.txtEtat.addItem("Neuf");
		this.txtEtat.addItem("Occasion");
		this.txtEtat.addItem("Inconnu");

		this.txtCategorie.addItem("Électronique");
		this.txtCategorie.addItem("Logiciel");
		this.txtCategorie.addItem("Matériel");
		this.txtCategorie.addItem("Réseau");

		this.txtStatut.addItem("En Attente");
		this.txtStatut.addItem("Acceptée");
		this.txtStatut.addItem("En cours");
		this.txtStatut.addItem("Terminée");
		this.txtStatut.addItem("Refusée");
	}
	
	
	public Object [][] obtenirDonnees (String filtre)
	{
		ArrayList <Intervention> lesInterventions = Controleur.selectLikeInterventions(filtre); // Remplacer par le filtre
		Object[][] matrice = new Object [lesInterventions.size()][14];
		
		int i = 0;
		for (Intervention uneIntervention : lesInterventions)
		{
			// Fetch le produit lié
			Produit unProduit = Controleur.getProduitById(uneIntervention.getIdproduit());
			
			String nomClient = Controleur.getUsername(uneIntervention.getIdclient());
			String nomTech = Controleur.getUsername(uneIntervention.getIdtechnicien());
			
			matrice[i][0] = uneIntervention.getIdintervention();
			matrice[i][1] = unProduit.getNom();
			matrice[i][2] = unProduit.getMarque();
			matrice[i][3] = unProduit.getEtat();
			matrice[i][4] = unProduit.getCategorie();
			matrice[i][5] = uneIntervention.getDateCreation();
			matrice[i][6] = uneIntervention.getDateAcceptee();
			matrice[i][7] = uneIntervention.getDateInter();
			matrice[i][8] = uneIntervention.getPrix();
			matrice[i][9] = uneIntervention.getDuree();
			matrice[i][10] = uneIntervention.getDescription();
			matrice[i][11] = uneIntervention.getStatut();
			matrice[i][12] = nomTech;
			matrice[i][13] = nomClient;
			i++;
		}
		
		return matrice;
	}
	
	// Retire les accents de la chaine passée en paramètre
	public static String stripAccents(String s) 
	{
	    s = Normalizer.normalize(s, Normalizer.Form.NFD);
	    s = s.replaceAll("[\\p{InCombiningDiacriticalMarks}]", "");
	    return s;
	}
	
	public void viderChamps()
	{
		this.txtNomProduit.setText("");
		this.txtMarque.setText("");
		this.txtDateCreationIntervention.setText("");
		this.txtDateInterventionAcceptee.setText("");
		this.dateInter.setText("");
		this.txtPrix.setText("");
		this.txtDuree.setText("");
		this.txtDescription.setText("");
	}

	
	

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == this.btAnnuler)
		{
			this.txtNomProduit.setText("");
			this.txtMarque.setText("");
			this.txtDateCreationIntervention.setText("");
			this.txtDateInterventionAcceptee.setText("");
			this.dateInter.setText("");
			this.txtPrix.setText("");
			this.txtDuree.setText("");
			this.txtDescription.setText("");
			
			btEnregistrer.setText("Enregistrer");
		}
	
		else if (e.getSource() == this.btEnregistrer && this.btEnregistrer.getText().equals("Enregistrer"))
		{
			/*
			 * On récupère les données du form
			 */
			String nomProduit = this.txtNomProduit.getText();
			String marque = this.txtMarque.getText();
			String dateCreation = this.txtDateCreationIntervention.getText();
			String dateAcceptee = this.txtDateInterventionAcceptee.getText();
			String dateInter = this.dateInter.getText();
			int duree = Integer.valueOf(this.txtDuree.getText());
			String description = this.txtDescription.getText();
			float prix = 0;
			
			try {
				prix = Float.parseFloat(this.txtPrix.getText());
			} catch (NumberFormatException exp) {
				JOptionPane.showMessageDialog(this, "Erreur prix");
			}
			
			// Récupération les ID
			String chaine = this.txtIdTechnicien.getSelectedItem().toString();
			String tab[] = chaine.split("-");
			int idTechnicien = Integer.parseInt(tab[0]);
			
			chaine = this.txtIdClient.getSelectedItem().toString();
			tab = chaine.split("-");
			int idClient = Integer.parseInt(tab[0]);
			
			// Autres ComboBox
			chaine = this.txtEtat.getSelectedItem().toString().toLowerCase();
			String etat = stripAccents(chaine);
			
			chaine = this.txtCategorie.getSelectedItem().toString().toLowerCase();
			String categorie = stripAccents(chaine);
			
			chaine = this.txtStatut.getSelectedItem().toString().toLowerCase();
			String statut = stripAccents(chaine);
			
			// On vérifie que les infos necessaires sont presentes
			if (nomProduit.isEmpty() || marque.isEmpty() || dateCreation.isEmpty() || description.isEmpty())
			{
				JOptionPane.showMessageDialog(this, "Erreur : Information manquante");
				return;
			}
			if (!statut.equals("en attente"))
			{
				if (prix == 0 || duree == 0 || dateAcceptee.isEmpty() || dateInter.isEmpty())
				{
					JOptionPane.showMessageDialog(this, "Erreur : Information manquante");
					return;
				}
			}
			
			
			
			// Instancier un Produit
			Produit unProduit = new Produit (nomProduit, marque, "", etat, categorie, idClient);
			
			// On l'insere dans la BDD
			Controleur.insertProduit(unProduit);
			
			// On récupère l'ID du produit
			int idProduit = Controleur.selectProduitId(unProduit);
			
			// Instancier une intervention
			Intervention uneIntervention = new Intervention (dateCreation, dateAcceptee, dateInter, description, statut, prix, duree,
					idProduit, idTechnicien, idClient);
			
			// On l'insere dans la BDD
			Controleur.insertIntervention(uneIntervention);
			JOptionPane.showMessageDialog(this, "Insertion réussie de l'intervention");

			/***********************************/
			// Modification dans l'affichage
			String nomClient = Controleur.getUsername(idClient);
			String nomTech = Controleur.getUsername(idTechnicien);
			// L'ID s'affichera lors du prochain chargement de la page
			Object ligne [] = {"reload", nomProduit, marque, etat, categorie, dateCreation, dateAcceptee,
					dateInter, prix, duree, description, statut, nomTech, nomClient};
			this.unTableau.ajouterLigner(ligne);
			this.viderChamps();
		}
		
		else if (e.getSource() == this.btEnregistrer && this.btEnregistrer.getText().equals("Modifier"))
		{
			/*
			 * On récupère les données du form
			 */
			String nomProduit = this.txtNomProduit.getText();
			String marque = this.txtMarque.getText();
			String dateCreation = this.txtDateCreationIntervention.getText();
			String dateAcceptee = this.txtDateInterventionAcceptee.getText();
			String dateInter = this.dateInter.getText();
			int duree = Integer.valueOf(this.txtDuree.getText());
			String description = this.txtDescription.getText();
			float prix = 0;
			
			try {
				prix = Float.parseFloat(this.txtPrix.getText());
			} catch (NumberFormatException exp) {
				JOptionPane.showMessageDialog(this, "Erreur prix");
			}
			
			// Récupération les ID
			String chaine = this.txtIdTechnicien.getSelectedItem().toString();
			String tab[] = chaine.split("-");
			int idTechnicien = Integer.parseInt(tab[0]);
			
			chaine = this.txtIdClient.getSelectedItem().toString();
			tab = chaine.split("-");
			int idClient = Integer.parseInt(tab[0]);
			
			// Autres ComboBox
			chaine = this.txtEtat.getSelectedItem().toString().toLowerCase();
			String etat = stripAccents(chaine);
			
			chaine = this.txtCategorie.getSelectedItem().toString().toLowerCase();
			String categorie = stripAccents(chaine);
			
			chaine = this.txtStatut.getSelectedItem().toString().toLowerCase();
			String statut = stripAccents(chaine);
			
			// On récupère l'ID de l'intervention
			int idIntervention = 0;
			int numLigne = 0;
			numLigne = tableProduits.getSelectedRow();
			idIntervention = Integer.parseInt(tableProduits.getValueAt(numLigne,  0).toString());
			// Et celui du produit lié
			int idProduit = Controleur.getInterventionProduitId(idIntervention);
			
			// Intanciation d'un Produit & d'une Intervention
			Produit unProduit = new Produit (idProduit, nomProduit, marque, "", etat, categorie, idClient);
			Intervention uneIntervention = new Intervention (idIntervention, dateCreation, dateAcceptee, dateInter, description, statut, prix, duree,
					idProduit, idTechnicien, idClient);
			// Modification dans la BDD
			Controleur.updateProduit(unProduit);
			Controleur.updateIntervention(uneIntervention);
	
			
			// Modification dans l'affichage
			String nomClient = Controleur.getUsername(idClient);
			String nomTech = Controleur.getUsername(idTechnicien);
			Object ligne [] = {idIntervention, nomProduit, marque, etat, categorie, dateCreation, dateAcceptee,
					dateInter, prix, duree, description, statut, nomTech, nomClient};
			this.unTableau.modifierLigne(numLigne, ligne);
			JOptionPane.showMessageDialog(this, "Modification effectuée");
			this.viderChamps();
			this.btEnregistrer.setText("Enregistrer");
		}
		
		else if(e.getSource() == this.btFiltre)
		{
			String filtre = this.txtFiltre.getText();
			Object matrice [][] = this.obtenirDonnees(filtre);
			this.unTableau.setDonnees(matrice);
		}
		
		else if(e.getSource() == this.btEnleverFiltre)
		{
			Object matrice [][] = this.obtenirDonnees("");
			this.unTableau.setDonnees(matrice);
		}
	}
}
