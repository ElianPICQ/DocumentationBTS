package vue;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;

import controleur.Utilisateur;
import controleur.Controleur;
import controleur.Tableau;
import controleur.Technicien;
import controleur.Client;


public class PanelUtilisateurs extends PanelPrincipal implements ActionListener
{
	private JTextField txtNomUser = new JTextField();
	private JTextField txtPrenomUser = new JTextField();
	private JTextField txtEmailUser = new JTextField();
	private JTextField txtMdpUser = new JTextField();
	private JTextField txtConfirmMdpUser = new JTextField();
	private JTextField txtTel = new JTextField();
	private JComboBox<String> txtRole = new JComboBox<String>();
	
	private JTextField txtCodePostal = new JTextField();
	private JTextField txtDateNaissance = new JTextField();
	
	private JTextField txtCompetence = new JTextField();
	private JTextField txtDateEmbauche = new JTextField();
	
	private JButton btAnnuler = new JButton("Annuler");
	private JButton btEnregistrer = new JButton("Enregistrer");

	private JPanel panelForm = new JPanel();
	private JPanel panelFormClient = new JPanel();
	private JPanel panelFormTech = new JPanel();
	private JPanel panelFormBtns = new JPanel();

	// Table affichage
	private JTable tableUsers;
	private JScrollPane unScroll;
	private Tableau unTableau;

	// Champ & bouton filtre
	private JPanel panelRech = new JPanel();
	private JTextField txtFiltre = new JTextField("", 20);
	private JButton btFiltre = new JButton("Filtrer");
	private JButton btEnleverFiltre = new JButton("X");
	
	public PanelUtilisateurs()
	{
		super(Color.gray);
		
		this.panelForm.setBounds(10, 50, 270, 210);
		this.panelForm.setBackground(new Color(181, 135, 79));
		this.panelForm.setLayout(new GridLayout(7, 2));
		
		this.panelForm.add(new JLabel("NOM : ", SwingConstants.RIGHT));
		this.panelForm.add(this.txtNomUser);
		this.panelForm.add(new JLabel("Prenom : ", SwingConstants.RIGHT));
		this.panelForm.add(this.txtPrenomUser);
		this.panelForm.add(new JLabel("Email : ", SwingConstants.RIGHT));
		this.panelForm.add(this.txtEmailUser);
		this.panelForm.add(new JLabel("MDP : ", SwingConstants.RIGHT));
		this.panelForm.add(this.txtMdpUser);
		this.panelForm.add(new JLabel("Confirmer MDP : ", SwingConstants.RIGHT));
		this.panelForm.add(this.txtConfirmMdpUser);
		this.panelForm.add(new JLabel("Tel : ", SwingConstants.RIGHT));
		this.panelForm.add(this.txtTel);
		this.panelForm.add(new JLabel("Role : ", SwingConstants.RIGHT));
		this.panelForm.add(this.txtRole);
		
		this.panelFormClient.setBounds(10, 260, 270, 60);
		this.panelFormClient.setBackground(new Color(255, 0, 0));
		this.panelFormClient.setLayout(new GridLayout(2, 2));
		
		this.panelFormClient.add(new JLabel("Code Postal : "));
		this.panelFormClient.add(this.txtCodePostal);
		this.panelFormClient.add(new JLabel("Date de Naissance : "));
		this.panelFormClient.add(this.txtDateNaissance);
		
		this.panelFormTech.setBounds(10, 260, 270, 60);
		this.panelFormTech.setBackground(new Color(255, 0, 0));
		this.panelFormTech.setLayout(new GridLayout(2, 2));
		
		this.panelFormTech.add(new JLabel("Compétence : "));
		this.panelFormTech.add(this.txtCompetence);
		this.panelFormTech.add(new JLabel("Date d'embauche : "));
		this.panelFormTech.add(this.txtDateEmbauche);
		
		this.panelFormBtns.setBounds(10, 315, 270, 30);
		this.panelFormBtns.setBackground(new Color(255, 0, 0));
		this.panelFormBtns.setLayout(new GridLayout(1, 2));
		
		this.panelFormBtns.add(this.btAnnuler);
		this.panelFormBtns.add(this.btEnregistrer);
		
		this.add(this.panelForm);
		this.add(this.panelFormClient);
		this.add(this.panelFormTech);
		this.add(this.panelFormBtns);

		this.panelForm.setVisible(true);
		this.panelFormClient.setVisible(false);
		this.panelFormTech.setVisible(false);
		this.panelFormBtns.setVisible(true);
		
		this.remplirCBX();
		
		
		// Affichage des Utilisateurs
		// Construction de la JTable
		String entetes [] = {"ID Utilisateur", "Role", "NOM", "Prenom", "Email", "Num. tel", "Code Postal", "Date de Naiss.", "Competence", "Date d'embauche"};
		
		this.unTableau = new Tableau (entetes, this.obtenirDonnees(""));
		this.tableUsers = new JTable(this.unTableau);
		
		this.unScroll = new JScrollPane(this.tableUsers);
		this.unScroll.setBounds(290, 50, 800, 295);
		this.add(this.unScroll);
		
		// Permet le scroll horizontal
		this.tableUsers.setAutoResizeMode( JTable.AUTO_RESIZE_OFF );
		
		// Interdiction de déplacement des colonnes
		this.tableUsers.getTableHeader().setReorderingAllowed(false);
		
		// Placemement du panel filtre
		this.panelRech.setBounds(450, 10, 300, 20);
		this.panelRech.setBackground(new Color(152, 45, 20));
		this.panelRech.setLayout(new GridLayout(1, 4));
		this.panelRech.add(this.btEnleverFiltre);
		this.panelRech.add(new JLabel("Filtrer par : "));
		this.panelRech.add(this.txtFiltre);
		this.panelRech.add(this.btFiltre);
		this.panelRech.setVisible(true);
		this.add(this.panelRech);
		
		// Ecouter les changements sur le ComboBox Role
		this.txtRole.addItemListener(new ItemListener( ) {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == 1) {
					panelFormClient.setVisible(false);
					panelFormTech.setVisible(false);
					
					Object item = e.getItem();
					
					switch (item.toString()) {
						case "Client": panelFormClient.setVisible(true); break;
						case "Technicien": panelFormTech.setVisible(true); break;
						default: break;
					}
				}
			}
		});

		// On centre les infos dans le tableau
		DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);

        for (int i = 0 ; i < entetes.length ; i++)
        {
	        tableUsers.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
        
        // On donne manuellement la largeur des colonnes
        tableUsers.getColumnModel().getColumn(0).setMinWidth(100);
        tableUsers.getColumnModel().getColumn(1).setMinWidth(100);
        tableUsers.getColumnModel().getColumn(2).setMinWidth(100);
        tableUsers.getColumnModel().getColumn(3).setMinWidth(100);
        tableUsers.getColumnModel().getColumn(4).setMinWidth(100);
        tableUsers.getColumnModel().getColumn(5).setMinWidth(100);
        tableUsers.getColumnModel().getColumn(6).setMinWidth(100);
        tableUsers.getColumnModel().getColumn(7).setMinWidth(100);
        tableUsers.getColumnModel().getColumn(8).setMinWidth(100);
        tableUsers.getColumnModel().getColumn(9).setMinWidth(100);
		
		// Ajout d'un 'mouse listener' pour la suppression et la modification
		this.tableUsers.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseClicked(MouseEvent e)
			{
				int numLigne = 0;
				int idUtilisateur = 0;
				
				numLigne = tableUsers.getSelectedRow();
				idUtilisateur = Integer.parseInt(tableUsers.getValueAt(numLigne,  0).toString());
				
				if (e.getClickCount() >= 2)
				{
					int reponse = JOptionPane.showConfirmDialog(null, "Voulez vous vraiment supprimer cet utilisateur?", "Suppression Utilisateur", JOptionPane.YES_NO_OPTION);
					
					if (reponse == 0)
					{
						// Suppression dans la BDD
						Controleur.deleteUtilisateur(idUtilisateur);
						// Suppression dans la table affichée
						unTableau.supprimerLigner(numLigne);
						// Repréparer le formulaire pour enregistrement
						btEnregistrer.setText("Enregistrer");
						txtRole.setVisible(true);
						viderChamps();
					}
				}
				else
				{
					String role = tableUsers.getValueAt(numLigne, 1).toString();
					String nom = tableUsers.getValueAt(numLigne, 2).toString();
					String prenom = tableUsers.getValueAt(numLigne, 3).toString();
					String email = tableUsers.getValueAt(numLigne, 4).toString();
					String tel = tableUsers.getValueAt(numLigne, 5).toString();
					String codePostal = "";
					String dateNaissance = "";
					String competence = "";
					String dateEmbauche = "";
					
					// On cache le role pour ne pas pouvoir le changer
					txtRole.setVisible(false);
					// Et le form qui va avec por mieux l'afficher apres
					panelFormClient.setVisible(false);
					panelFormTech.setVisible(false);
					
					// On affiche les inputs Client ou Technicien en fonction de l'utilisateur cliqué
					switch (role) {
						case "client":
							panelFormClient.setVisible(true);
							codePostal = tableUsers.getValueAt(numLigne, 6) == null ? "" : tableUsers.getValueAt(numLigne, 6).toString();
							dateNaissance = tableUsers.getValueAt(numLigne, 7) == null ? "" : tableUsers.getValueAt(numLigne, 7).toString();
							break;
							
						case "technicien":
							panelFormTech.setVisible(true);
							competence = tableUsers.getValueAt(numLigne, 8) == null ? "" : tableUsers.getValueAt(numLigne, 8).toString();
							dateEmbauche = tableUsers.getValueAt(numLigne, 9) == null ? "" : tableUsers.getValueAt(numLigne, 9).toString();
							break;
							
						default:
							panelFormTech.setVisible(false);
							panelFormClient.setVisible(false);
							break;
					}
					
					// Remplissage du formulaire
					txtNomUser.setText(nom);
					txtPrenomUser.setText(prenom);
					txtEmailUser.setText(email);
					txtTel.setText(tel);
					txtCodePostal.setText(codePostal);
					txtDateNaissance.setText(dateNaissance);
					txtCompetence.setText(competence);
					txtDateEmbauche.setText(dateEmbauche);
						
					btEnregistrer.setText("Modifier");
				}
			}
		});
		
		// Rendre les boutons cliquables
		this.btAnnuler.addActionListener(this);
		this.btEnregistrer.addActionListener(this);
		this.btFiltre.addActionListener(this);
		this.btEnleverFiltre.addActionListener(this);
	}
	
	public void remplirCBX()
	{
		this.txtRole.addItem("Administrateur");
		this.txtRole.addItem("Client");
		this.txtRole.addItem("Technicien");
	}
	
	
	
	public Object [][] obtenirDonnees (String filtre)
	{
		ArrayList <Utilisateur> lesUtilisateurs = Controleur.selectLikeUtilisateurs(filtre);
		Object[][] matrice = new Object [lesUtilisateurs.size()][10];
		
		int i = 0;
		for (Utilisateur unUtilisateur : lesUtilisateurs)
		{	
			matrice[i][0] = unUtilisateur.getIdutilisateur();
			matrice[i][1] = unUtilisateur.getRole();
			matrice[i][2] = unUtilisateur.getNom();
			matrice[i][3] = unUtilisateur.getPrenom();
			matrice[i][4] = unUtilisateur.getEmail();
			matrice[i][5] = unUtilisateur.getTel();
			
			
			// Fetch le Client ou Technicien associé
			String role = unUtilisateur.getRole();
			switch (role)
			{
			case "client":
				Client unClient = Controleur.getClientById(unUtilisateur.getIdutilisateur());
				
				if (unClient != null)
				{
					matrice[i][6] = unClient.getCodePostal();
					matrice[i][7] = unClient.getDateNaissance();
				}
				break;
			case "technicien":
				Technicien unTechnicien = Controleur.getTechnicienById(unUtilisateur.getIdutilisateur());
				
				if (unTechnicien != null)
				{
					matrice[i][8] = unTechnicien.getCompetence();
					matrice[i][9] = unTechnicien.getDateEmbauche();
				}
				break;
				
			default:
				break;
			}
			
			i++;
		}
		
		return matrice;
	}


	public void viderChamps()
	{
		this.txtNomUser.setText("");
		this.txtPrenomUser.setText("");
		this.txtEmailUser.setText("");
		this.txtMdpUser.setText("");
		this.txtConfirmMdpUser.setText("");
		this.txtTel.setText("");
		this.txtCodePostal.setText("");
		this.txtDateNaissance.setText("");
		this.txtCompetence.setText("");
		this.txtDateEmbauche.setText("");
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == this.btAnnuler)
		{
			this.viderChamps();
			txtRole.setVisible(true);
			
			btEnregistrer.setText("Enregistrer");
		}
		
		else if (e.getSource() == this.btEnregistrer && this.btEnregistrer.getText().equals("Enregistrer"))
		{
			// On récupère les données du formulaire
			String NomUser = this.txtNomUser.getText();
			String PrenomUser = this.txtPrenomUser.getText();
			String EmailUser = this.txtEmailUser.getText();
			String MdpUser = this.txtMdpUser.getText();
			String ConfirmMdpUser = this.txtConfirmMdpUser.getText();
			String TelUser = this.txtTel.getText();
			String RoleUser = this.txtRole.getSelectedItem().toString().toLowerCase();
			
			// On vérifie que les mdp soient identiques
			if (!MdpUser.equals(ConfirmMdpUser))
			{
				JOptionPane.showMessageDialog(this,  "Erreur : Les MDP doivent être identiques");
				return;
			}
			
			// On Instancie un Utilisateur avant de l'insérer dans la BDD
			Utilisateur unUtilisateur = new Utilisateur(NomUser, PrenomUser, EmailUser, TelUser, MdpUser, RoleUser);
			if (Controleur.insertUtilisateur(unUtilisateur) == -1)
			{
				JOptionPane.showMessageDialog(this,  "Erreur : Information manquante");
				return;
			}
			
			// On fetch l'utilisateur precedemment créé pour avoir son ID
			unUtilisateur = Controleur.selectWhereUtilisateur(EmailUser, MdpUser);
			int idutilisateur = unUtilisateur.getIdutilisateur();
			Object ligne [] = {idutilisateur, RoleUser, NomUser, PrenomUser, EmailUser, TelUser, "", "", "", ""};
			
			if (RoleUser.equals("client"))
			{
				int CodePostalUser = 0;
				
				try {
					CodePostalUser = Integer.valueOf(this.txtCodePostal.getText());
		        } catch (NumberFormatException nfe) {
		            System.out.println("NumberFormat Exception: invalid input string" + "\n" + nfe);
		        }
				
				String DateNaissanceUser = this.txtDateNaissance.getText();
				
				if (DateNaissanceUser.isEmpty())
				{
					DateNaissanceUser = "1000-01-01";
				}
				
				// On instancie un Client avant de l'insérer dans la BDD
				Client unClient = new Client(idutilisateur, CodePostalUser, DateNaissanceUser);
				Controleur.insertClient(unClient);

				ligne[6] = CodePostalUser;
				ligne[7] = DateNaissanceUser;
			}
			else if (RoleUser.equals("technicien"))
			{
				String CompetenceUser = this.txtCompetence.getText();
				String DateEmbaucheUser = this.txtDateEmbauche.getText();
				
				// On instancie un Technicien avant de l'insérer dans la BDD
				Technicien unTechnicien = new Technicien(idutilisateur, CompetenceUser, DateEmbaucheUser);
				Controleur.insertTechnicien(unTechnicien);

				ligne[8] = CompetenceUser;
				ligne[9] = DateEmbaucheUser;
			}
			
			/********* Une fois l'insertion terminée ***********/
			this.unTableau.ajouterLigner(ligne);
			JOptionPane.showMessageDialog(this,  "Insertion réussie de l'utilisateur");
			this.viderChamps();
		}
		
		else if (e.getSource() == this.btEnregistrer && this.btEnregistrer.getText().equals("Modifier"))
		{
			String NomUser = this.txtNomUser.getText();
			String PrenomUser = this.txtPrenomUser.getText();
			String EmailUser = this.txtEmailUser.getText();
			String MdpUser = this.txtMdpUser.getText();
			String ConfirmMdpUser = this.txtConfirmMdpUser.getText();
			String TelUser = this.txtTel.getText();
			String RoleUser = this.txtRole.getSelectedItem().toString().toLowerCase();

			// On récupère l'ID de l'utilisateur
			int idUtilisateur = 0;
			int numLigne = 0;
			numLigne = tableUsers.getSelectedRow();
			idUtilisateur = Integer.parseInt(tableUsers.getValueAt(numLigne,  0).toString());
			
			// On vérifie que les mdp soient identiques
			if (!MdpUser.equals(ConfirmMdpUser))
			{
				JOptionPane.showMessageDialog(this,  "Les MDP doivent être identiques");
				return;
			}
		

			// On Instancie un Utilisateur avant de le modifier dans la BDD
			Utilisateur unUtilisateur = new Utilisateur(idUtilisateur, NomUser, PrenomUser, EmailUser, TelUser, MdpUser, RoleUser);
			Controleur.modifierUtilisateur(unUtilisateur);
			
			// On prepare la ligne du tableau à afficher
			Object ligne [] = {idUtilisateur, RoleUser, NomUser, PrenomUser, EmailUser, TelUser, "", "", "", ""};
			
			// On vérifie si il y a eu changement de role
			String ancientRole = tableUsers.getValueAt(numLigne,  1).toString();
			
			if (RoleUser.equals("client"))
			{
				int CodePostalUser = 0;
				try {
					CodePostalUser = Integer.valueOf(this.txtCodePostal.getText());
		        } catch (NumberFormatException nfe) {
		            System.out.println("NumberFormat Exception: invalid input string" + "\n" + nfe);
		        }
				
				String DateNaissanceUser = this.txtDateNaissance.getText();
				
				// On instancie un Client avant de le modifier dans la BDD
				Client unClient = new Client(idUtilisateur, CodePostalUser, DateNaissanceUser);
				Controleur.modifierClient(unClient);

				ligne[6] = CodePostalUser;
				ligne[7] = DateNaissanceUser;
			}
			else if (RoleUser.equals("technicien"))
			{
				String CompetenceUser = this.txtCompetence.getText();
				String DateEmbaucheUser = this.txtDateEmbauche.getText();
				
				// On instancie un Technicien avant de le modifier dans la BDD
				Technicien unTechnicien = new Technicien(idUtilisateur, CompetenceUser, DateEmbaucheUser);
				Controleur.modifierTechnicien(unTechnicien);

				ligne[8] = CompetenceUser;
				ligne[9] = DateEmbaucheUser;
			}
			
			/********* Une fois la modification terminée ***********/
			
			this.unTableau.modifierLigne(numLigne, ligne);
			JOptionPane.showMessageDialog(this,  "Modification réussie de l'utilisateur");
			this.btEnregistrer.setText("Enregistrer");
			txtRole.setVisible(true);
			this.viderChamps();
		}

		else if(e.getSource() == this.btFiltre)
		{
			String filtre = this.txtFiltre.getText();
			Object matrice [][] = this.obtenirDonnees(filtre);
			this.unTableau.setDonnees(matrice);
		}
		
		else if(e.getSource() == this.btEnleverFiltre)
		{
			Object matrice [][] = this.obtenirDonnees("");
			this.unTableau.setDonnees(matrice);
		}
	}
}












