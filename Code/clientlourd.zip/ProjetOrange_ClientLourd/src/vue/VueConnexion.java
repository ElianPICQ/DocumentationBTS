package vue;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JTextField;

import controleur.Controleur;
import controleur.ProjetOrange;
import controleur.Utilisateur;

import javax.swing.JPasswordField;
import javax.swing.JPanel;

import javax.swing.JFrame;


public class VueConnexion extends JFrame implements ActionListener, KeyListener {

	private JButton btConnexion = new JButton ("Se Connecter");
	private JButton btAnnuler = new JButton ("Annuler");
	
	private JTextField txtEmail = new JTextField("admin@mail.com");
	private JPasswordField txtMdp = new JPasswordField("123");
	
	public VueConnexion() {
		this.setTitle("Projet BTS Orange");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(200, 200, 600, 300);
		this.getContentPane().setBackground(new Color(51, 51, 51));
		this.setLayout(null);
		this.setResizable(false);
		
		// installer le logo
		ImageIcon uneImage = new ImageIcon("src/images/logo_orange.png");
		JLabel labelLogo = new JLabel(uneImage);
		labelLogo.setBounds(40, 40, 200, 200);
		this.add(labelLogo);
		
		// Setup police
		Font font = new Font("Helvetica", Font.BOLD, 20);
		
		// Pannel Connexion
		JPanel panelConnexion = new JPanel();
		panelConnexion.setBounds(260, 40, 300, 200);
		panelConnexion.setBackground(new Color(51, 51, 51));
		panelConnexion.setLayout(new GridLayout(3, 2));
		

		// panelConnexion.add(new JLabel("Email : "));
		JLabel txt = new JLabel("Email : ");
		txt.setForeground(Color.white);
		txt.setFont(font);
		panelConnexion.add(txt);
		
		panelConnexion.add(this.txtEmail);
		
		// panelConnexion.add(new JLabel("MDP : "));
		JLabel txt2 = new JLabel("MDP : ");
		txt2.setForeground(Color.white);
		txt2.setFont(font);
		panelConnexion.add(txt2);
		panelConnexion.add(this.txtMdp);
		
		panelConnexion.add(this.btAnnuler);
		panelConnexion.add(this.btConnexion);
		
		this.add(panelConnexion);

		// On rend les boutons écoutables
		this.btAnnuler.addActionListener(this);
		this.btConnexion.addActionListener(this);
		// On rend les champs de saisie écoutables
		this.txtEmail.addKeyListener(this);
		this.txtMdp.addKeyListener(this);
		
		this.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == this.btAnnuler)
		{
			this.txtEmail.setText("");
			this.txtMdp.setText("");
		}
		else if (e.getSource() == this.btConnexion)
		{
			this.traitement();
		}
		
	}

	public void traitement()
	{
		String email = this.txtEmail.getText();
		String mdp = new String(this.txtMdp.getPassword());
		
		// On verifie dans la BDD
		Utilisateur unAdministrateur = Controleur.selectWhereAdministrateur(email, mdp);
		if (unAdministrateur == null)
		{
			JOptionPane.showMessageDialog(this,  "Veuillez vérifier vos identifiants");
			this.txtEmail.setText("");
			this.txtMdp.setText("");
		}
		else
		{
			//On lance la vue generale et on reduit la vue connexion
			ProjetOrange.rendreVisibleGenerale(true, unAdministrateur);
			ProjetOrange.rendreVisibleConnexion(false);
		}
	}
	
	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_ENTER)
		{
			this.traitement();
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
}

