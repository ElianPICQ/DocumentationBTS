package vue;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;

import controleur.ProjetOrange;
import controleur.Utilisateur;

import javax.swing.JButton;

public class VueGenerale extends JFrame implements ActionListener
{
	private JButton btAccueil = new JButton("Accueil");
	private JButton btUtilisateurs = new JButton("Utilisateurs");
	private JButton btInterventions = new JButton("Interventions");
	private JButton btQuitter = new JButton("Quitter");

	private JPanel panelMenu = new JPanel ();

	private static PanelInterventions unPanelInterventions = new PanelInterventions();
	private static PanelUtilisateurs unPanelUtilisateurs = new PanelUtilisateurs();
	private static PanelAccueil unPanelAccueil;

	
	
	public VueGenerale(Utilisateur unUtilisateur) {
		VueGenerale.unPanelAccueil = new PanelAccueil(unUtilisateur);
	//	unPanelAccueil.remplirDonnees(unUtilisateur);
		
		this.setTitle("Projet BTS Orange");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(175, 15, 1200, 800);
		this.getContentPane().setBackground(new Color(215, 215, 215));
		this.setLayout(null);
		this.setResizable(false);
		
		// On place les boutons
		panelMenu.setBounds(100, 20, 900, 30);
		panelMenu.setLayout(new GridLayout(1, 5));
		panelMenu.setBackground(new Color(0, 0, 200));
		panelMenu.add(this.btAccueil);
		panelMenu.add(this.btUtilisateurs);
		panelMenu.add(this.btInterventions);
		panelMenu.add(this.btQuitter);
		this.add(panelMenu);
		
		// Rendre les boutons cliquables
		this.btAccueil.addActionListener(this);
		this.btUtilisateurs.addActionListener(this);
		this.btInterventions.addActionListener(this);
		this.btQuitter.addActionListener(this);

		// Ajout des Panels dans la fenêtre
		this.add(unPanelAccueil);
		this.add(unPanelInterventions);
		this.add(unPanelUtilisateurs);
		
		unPanelAccueil.setVisible(true);
		this.setVisible(true);
	}


	public void afficher(int choix)
	{
		unPanelAccueil.setVisible(false);
		unPanelUtilisateurs.setVisible(false);
		unPanelInterventions.setVisible(false);
		
		switch(choix)
		{
			case 1 : unPanelAccueil.setVisible(true); break;
			case 2 : unPanelUtilisateurs.setVisible(true); break;
			case 3 : unPanelInterventions.setVisible(true); break;
			default: break;
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (this.btQuitter == e.getSource())
		{
			ProjetOrange.rendreVisibleGenerale(false, null);
			ProjetOrange.rendreVisibleConnexion(true);
		}
		

		else if (this.btAccueil == e.getSource())
			afficher(1);
		
		else if (this.btUtilisateurs == e.getSource())
			afficher(2);
		
		else if (this.btInterventions == e.getSource())
			afficher(3);
	}
	
	
}
